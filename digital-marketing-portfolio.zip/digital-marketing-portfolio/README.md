# GrowWave — Digital Marketing Portfolio Website

A responsive digital marketing agency portfolio project created using **HTML, CSS, and JavaScript**. Designed as a beginner-friendly project for a GitHub portfolio, college assignment, or internship showcase.

## Features
- Modern agency landing page
- Responsive mobile navigation
- Digital marketing service cards: SEO, paid ads, social media, email
- Campaign analytics illustration and sample performance metrics
- Sample campaign case study
- Contact/enquiry form with front-end validation and demo success message
- Responsive layout for desktop, tablet, and mobile

## Run the project
1. Download or clone this repository.
2. Open `index.html` in any modern browser.
3. No package installation or build step is required.

## Project files
```text
digital-marketing-portfolio/
├── index.html
├── style.css
├── script.js
└── README.md
```

## Publish on GitHub Pages
1. Create a repository on [GitHub](https://github.com/new), e.g. `digital-marketing-portfolio`.
2. Upload all four files to the repository root and commit the changes.
3. Open **Settings → Pages**.
4. Choose **Deploy from a branch**, select `main` and `/(root)`, then save.
5. Wait for the published URL to appear in the Pages section.

## Important notes
- GrowWave is a fictional demo brand.
- All analytics/results are illustrative sample figures, not verified client results.
- The contact form is front-end only. It displays a confirmation message but does not send emails or store form submissions.

## Suggested repository description
`Responsive digital marketing agency portfolio built with HTML, CSS, and JavaScript.`

## Suggested commit message
`Build responsive digital marketing portfolio website`
